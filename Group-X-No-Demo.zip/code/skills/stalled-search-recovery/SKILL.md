---
name: stalled-search-recovery
description: Recover from searches that return nothing or repeat already seen documents. Use when the most recent search adds no new document IDs.
metadata:
  trigger: stalled-search
---

## Recover from a stalled search

1. Review the recent search strings and available document IDs. Choose one term
   that can be dropped or replaced while preserving the clue it represented.
2. Retry with a genuinely different anchor, such as a shorter name, a spelling
   variant, a date, or the organization that owns the source. Search for one
   anchor and one distinguishing term at a time.
3. If the result list is still repetitive, inspect the most promising visited
   source using a phrase or a different offset. Look for exact entity names
   and relations to use in another query.
4. Preserve the best supported candidate. When the remaining budget offers no
   useful disambiguating action, return the strongest supported value or an
   empty answer when no evidence supports a candidate.
