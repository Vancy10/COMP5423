---
name: constraint-chain
description: Decompose questions with linked clues, resolve an intermediate entity, and confirm that the proposed answer fits the whole chain. Use when a question combines several constraints or asks for an attribute through an unnamed entity.
metadata:
  trigger: multiple-clues
---

## Resolve a chain of constraints

1. Identify the kind of answer requested and the entity it describes. Pick the
   most distinctive clue for the first search. Preserve quoted names, dates,
   and unusual terms in full.
2. Inspect the returned excerpts for a candidate entity. If search results
   describe the clue without naming the entity, open the strongest source at
   the excerpt or find a phrase that would tie them together.
3. Put the candidate name into the next query with one unresolved constraint.
   Compare alternatives when the same name occurs in different contexts.
4. Verify the requested attribute in a source passage and cite the document IDs
   that establish the bridge and the final fact. Keep only the requested value
   in the answer field.
