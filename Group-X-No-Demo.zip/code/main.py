"""Command line entry point for indexing, interactive search and batch runs."""

import argparse
import json
from pathlib import Path
import sqlite3
import sys

from search_agent.corpus import CORPUS_SIZE, Corpus, build_index, documents_from_parquet
from search_agent.llm import FlashClient, ModelError
from search_agent.resources import fetch
from search_agent.retrieval import PROFILES, Retriever

SOURCE = Path(__file__).resolve().parent
DEFAULT_METHOD = "hybrid"


def limit(low: int, high: int):
    def read(text: str) -> int:
        value = int(text)
        if not low <= value <= high:
            raise argparse.ArgumentTypeError(f"Select a value from {low} to {high}")
        return value
    return read


def parser() -> argparse.ArgumentParser:
    app = argparse.ArgumentParser(description=__doc__)
    app.add_argument("--data", type=Path, default=SOURCE.parent / "data")
    app.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    commands = app.add_subparsers(dest="command", required=True)
    download = commands.add_parser("fetch", help="Download pinned public assets")
    download.add_argument("assets", choices=("splits", "corpus", "dense", "instruct", "all"))
    indexing = commands.add_parser("index", help="Build or prepare corpus-wide indexes")
    indexing.add_argument("--method", choices=("sparse", "dense", "instruct", "hybrid"), default="hybrid")
    indexing.add_argument("--batch-size", type=limit(1, 512), default=48)
    indexing.add_argument("--rebuild", action="store_true")
    for command in ("ask", "shell", "batch", "retrieve", "evaluate-retrieval"):
        entry = commands.add_parser(command)
        entry.add_argument("--method", choices=tuple(PROFILES), default=DEFAULT_METHOD)
        if command in {"ask", "shell", "batch"}:
            entry.add_argument("--rounds", type=limit(1, 12), default=6)
            entry.add_argument("--max-calls", type=limit(1, 24), default=9)
            entry.add_argument("--disable-skills", action="store_true")
        if command in {"ask", "retrieve"}:
            entry.add_argument("question")
        if command == "retrieve":
            entry.add_argument("--limit", type=limit(1, 6), default=4)
        if command == "batch":
            entry.add_argument("questions", type=Path)
            entry.add_argument("predictions", type=Path)
            entry.add_argument("--workers", type=limit(1, 12), default=3)
            entry.add_argument("--expected", type=limit(1, 10_000), default=100)
        if command == "evaluate-retrieval":
            entry.add_argument("questions", type=Path)
    for subcommand in ("evaluate", "validate"):
        entry = commands.add_parser(subcommand)
        entry.add_argument("questions", type=Path)
        entry.add_argument("predictions", type=Path)
        if subcommand == "validate":
            entry.add_argument("--expected", type=limit(1, 10_000), default=100)
    return app


def index(args) -> None:
    path = args.data / "corpus.sqlite"
    if args.rebuild or not path.is_file():
        size, _ = build_index(path, documents_from_parquet(args.data / "corpus"), CORPUS_SIZE)
        print(f"Indexed {size:,} documents", flush=True)
    corpus = Corpus(path)
    if corpus.count != CORPUS_SIZE:
        raise ValueError("This command expects the complete official corpus.")
    for channel in PROFILES[args.method]:
        if channel != "sparse":
            from search_agent.embeddings import build_vectors

            if args.rebuild or not (args.data / f"{channel}.npz").is_file():
                print(build_vectors(args.data, corpus, channel, args.device, args.batch_size))
    print(f"Ready: {args.method} | {corpus.count:,} documents")


def run(args) -> None:
    if args.command == "fetch":
        fetch(args.data, args.assets)
        return
    if args.command == "index":
        index(args)
        return
    if args.command == "validate":
        from search_agent.batch import validate_file

        print(json.dumps(validate_file(args.questions, args.predictions, args.expected), indent=2))
        return
    if args.command == "evaluate":
        from search_agent.evaluate import prediction_metrics

        print(json.dumps(prediction_metrics(args.questions, args.predictions), indent=2))
        return
    model = FlashClient() if args.command in {"ask", "shell", "batch"} else None
    corpus = Corpus(args.data / "corpus.sqlite")
    retriever = Retriever(corpus, args.data, args.method, args.device)
    if args.command == "retrieve":
        from search_agent.ui import show_retrieval

        show_retrieval(retriever.search(args.question, args.limit))
        return
    if args.command == "evaluate-retrieval":
        from search_agent.evaluate import retrieval_metrics

        print(json.dumps(retrieval_metrics(retriever, args.questions), indent=2))
        return
    from search_agent.agent import Agent
    from search_agent.skills import Skills
    from search_agent.ui import ask, shell

    agent = Agent(model, retriever, Skills(SOURCE / "skills", not args.disable_skills),
                  args.rounds, args.max_calls)
    if args.command == "ask":
        ask(agent, args.question)
    elif args.command == "shell":
        shell(agent)
    else:
        from search_agent.batch import run_batch

        if corpus.count != CORPUS_SIZE:
            raise ValueError("Batch runs require the complete official corpus.")
        print(json.dumps(run_batch(agent, args.questions, args.predictions, args.workers,
                                   args.expected, SOURCE), indent=2))


if __name__ == "__main__":
    try:
        run(parser().parse_args())
    except (ValueError, OSError, ModelError, sqlite3.Error) as error:
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
