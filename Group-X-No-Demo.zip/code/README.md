# COMP5423 Skill-Augmented Search Agent

The agent answers questions from the fixed BrowseComp-Plus corpus of 100,195 documents. It calls DeepSeek-V4-Flash through an OpenAI-compatible API and keeps the document search local. The terminal displays the answer, cited text, skill decisions, and tool calls.

## Setup

Use Python 3.12 in a virtual environment. The full-corpus retrieval experiment used SQLite 3.53.1, PyTorch 2.7.1 + CUDA 12.6, and an NVIDIA RTX 3070 Ti. CPU mode also supports all retrievers, with slower E5 indexing. Allow about 10 GB of free disk space for corpus files, indexes, and embedding weights, in addition to the Python environment.

```sh
python -m pip install -r requirements.txt
python main.py fetch all
python main.py index --method hybrid
```

Run the commands from this directory. The default asset directory is `../data`. To use a different location, place `--data PATH` before the command. The default `--device auto` uses CUDA when PyTorch detects it. For a CUDA 12.6 installation, install the PyTorch 2.7.1 wheel from the [official CUDA wheel index](https://download.pytorch.org/whl/cu126) before the remaining requirements.

`fetch all` downloads the course validation questions, course test questions, the Tevatron document collection, the two embedding models, and the benchmark authors' Qwen document-vector shards. It pins revisions and checks the SHA-256 digests of the corpus and vector shards. The encrypted benchmark question labels and relevance judgments are outside this workflow. E5 vectors and BM25 are built locally. Qwen3 vectors are checked and aligned to the SQLite document IDs, then used for instruction-conditioned search with a local query encoder.

For a smaller setup, fetch `splits` and `corpus` separately, use `index --method sparse`, and pass `--method sparse` on each search command. This profile uses the complete corpus and requires no embedding weights.

## Model API

Set `OPENROUTER_API_KEY` in the launch environment. The default model route is `deepseek/deepseek-v4-flash` ([V4 Flash 0423 on OpenRouter](https://openrouter.ai/deepseek/deepseek-v4-flash)). To enter a key privately on PowerShell:

```powershell
$privateKey = Read-Host 'OpenRouter API key' -AsSecureString
$env:OPENROUTER_API_KEY = [System.Net.NetworkCredential]::new('', $privateKey).Password
```

For another provider of the exact model, set `COMP5423_BASE_URL` to its HTTPS API root, `COMP5423_MODEL` to its DeepSeek-V4-Flash identifier, and `COMP5423_API_KEY` to the provider key. The provider must support function tools and return `usage.total_tokens`. DeepSeek's own legacy Flash alias [now resolves to V4.1](https://api-docs.deepseek.com/quick_start/pricing/). Keep API configuration, indexes, and model files on the machine that runs the system.

## Interactive use

```sh
python main.py shell
python main.py retrieve --method hybrid --limit 3 "National Geographic solar eclipse Armando Vega July 2019"
```

The prompt accepts plain-text questions and `:quit` ends the interactive session. `retrieve` shows ranked document IDs, scores, URLs, and snippets without making an API call. The agent exposes one `search(query, limit)` tool, one `visit(doc_id, query, start)` tool for a longer passage, and one `find(doc_id, phrase)` tool for literal matches.

## Reproduce the predictions and validation

```sh
python main.py validate ../data/test.jsonl ../test_prediction.jsonl
python main.py batch ../data/test.jsonl ../rerun_test_prediction.jsonl
python main.py evaluate-retrieval ../data/validation.jsonl
```

The batch run requires the full corpus and 100 unique question IDs by default. Each question is sent to the agent by itself. The output is written in the original question order after all records pass validation. The per-question trajectory records skill choices, actual model inputs and tool calls, tool results, the final answer, and API usage. If the run pauses, restart the same command to reuse completed records. Set `--workers 1` for low-concurrency API plans.

To measure a one-search baseline and compare it with the full iterative system, run the same validation questions in both configurations:

```sh
python main.py batch --method sparse --rounds 1 --max-calls 1 --disable-skills ../data/validation.jsonl ../validation_single.jsonl
python main.py batch --method hybrid ../data/validation.jsonl ../validation_full.jsonl
python main.py evaluate ../data/validation.jsonl ../validation_single.jsonl
python main.py evaluate ../data/validation.jsonl ../validation_full.jsonl
```

`evaluate` reports normalized exact match and the observed call and token totals. `evaluate-retrieval` compares answer-string coverage under BM25, E5, Qwen3-Embedding, and rank fusion. The retrieval experiment applies references after ranking and can be run locally without a key.

## Code structure

| Path | Role |
| --- | --- |
| `main.py` | Asset setup, terminal interface, batch generation, and evaluation commands |
| `search_agent/corpus.py`, `resources.py` | Pinned downloads, compressed source storage, and SQLite full-text index |
| `search_agent/retrieval.py`, `embeddings.py` | BM25, E5, instruction-conditioned Qwen3, rank fusion, and source passages |
| `search_agent/agent.py`, `llm.py`, `tools.py` | DeepSeek client, native tool schemas, iterative loop, and bounded evidence state |
| `search_agent/batch.py`, `dataset.py`, `evaluate.py` | Resumable generation, per-record validation, and metrics |
| `search_agent/skills.py`, `skills/*/SKILL.md` | Skill discovery, automatic triggers, and runtime procedure loading |
| `search_agent/ui.py` | Terminal presentation of the answer, evidence, skills, and tool activity |
