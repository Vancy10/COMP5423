"""Course JSONL I/O and normalized exact match."""

from collections.abc import Iterable
import json
from pathlib import Path
import re
import string
import tempfile
import unicodedata

ASCII_PUNCTUATION = str.maketrans("", "", string.punctuation)
ARTICLES = re.compile(r"\b(?:a|an|the)\b")


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8-sig") as source:
        for number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except ValueError as error:
                raise ValueError(f"Invalid JSON at {path.name}:{number}") from error
            if not isinstance(row, dict):
                raise ValueError(f"Expected a JSON object at {path.name}:{number}")
            rows.append(row)
    return rows


def questions(path: Path, expected: int | None = None, labeled: bool = False) -> list[dict]:
    rows = read_jsonl(path)
    if not rows or (expected is not None and len(rows) != expected):
        raise ValueError(f"Invalid question count in {path.name}: {len(rows)} (expected {expected})")
    ids = set()
    for row in rows:
        names = ("id", "question", "answer") if labeled else ("id", "question")
        if any(not isinstance(row.get(name), str) or not row[name].strip() for name in names):
            raise ValueError(f"Invalid or missing required fields in {path.name}")
        if row["id"] in ids:
            raise ValueError(f"Duplicate question ID: {row['id']}")
        ids.add(row["id"])
    return rows


def normalize(text: str) -> str:
    lower = text.lower().translate(ASCII_PUNCTUATION)
    if not lower.isascii():
        lower = "".join(char for char in lower if not unicodedata.category(char).startswith("P"))
    return " ".join(ARTICLES.sub(" ", lower).split())


def atomic_jsonl(path: Path, records: Iterable[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as output:
        temporary = Path(output.name)
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as output:
            for record in records:
                output.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)
