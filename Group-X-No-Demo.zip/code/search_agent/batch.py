"""Resumable generation and validation of the course prediction format."""

from collections import deque
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
from pathlib import Path
import json

from filelock import FileLock

from .agent import Agent, _final_answer, json_text
from .dataset import atomic_jsonl, questions, read_jsonl
from .llm import FlashClient, ModelError

FIELDS = {"id", "question", "answer", "trajectory", "tool_calls", "total_tokens"}


def validate_record(record: dict, question: dict) -> None:
    ident = question["id"]
    if set(record) != FIELDS or any(record[key] != question[key] for key in ("id", "question")):
        raise ValueError(f"Incorrect schema, ID or question text for {ident}")
    if not isinstance(record["answer"], str) or not isinstance(record["trajectory"], list):
        raise ValueError(f"Invalid answer or trajectory type for {ident}")
    if any(type(record[key]) is not int for key in ("tool_calls", "total_tokens")):
        raise ValueError(f"Invalid tool or token count for {ident}")
    calls = tokens = 0
    pending = deque()
    last_answer = None
    successful_search = False
    for step in record["trajectory"]:
        role = step.get("role")
        if pending and role != "tool":
            raise ValueError(f"Tool results are out of order for {ident}")
        if role == "assistant":
            usage = step.get("usage", {}).get("total_tokens")
            if type(usage) is not int or usage <= 0:
                raise ValueError(f"Missing per-call API usage for {ident}")
            tokens += usage
            emitted = step.get("tool_calls", [])
            calls += len(emitted)
            pending.extend((call["id"], call["function"]["name"]) for call in emitted)
            last_answer = None if emitted else _final_answer(step.get("content"))
        elif role == "tool":
            if not pending or pending.popleft() != (step["tool_call_id"], step["name"]):
                raise ValueError(f"Tool output has no corresponding call for {ident}")
            payload = json.loads(step["content"])
            successful_search |= step["name"] == "search" and isinstance(payload.get("results"), list)
        elif role not in {"system", "user"}:
            raise ValueError(f"Unrecognized trajectory role for {ident}")
    if pending or not successful_search or last_answer is None or last_answer[0] != record["answer"]:
        raise ValueError(f"Incomplete tool/answer trajectory for {ident}")
    if tokens != record["total_tokens"] or calls != record["tool_calls"]:
        raise ValueError(f"Trajectory totals disagree for {ident}")


def validate_file(source: Path, output: Path, expected: int) -> dict:
    rows = questions(source, expected)
    predictions = read_jsonl(output)
    refs = {row["id"]: row for row in rows}
    for record in predictions:
        key = record.get("id")
        if key not in refs:
            raise ValueError(f"Duplicate or unexpected prediction ID: {key}")
        validate_record(record, refs.pop(key))
    if refs:
        raise ValueError(f"Missing {len(refs)} prediction records")
    return {
        "records": len(predictions), "tool_calls": sum(row["tool_calls"] for row in predictions),
        "total_tokens": sum(row["total_tokens"] for row in predictions),
    }


def _fingerprint(rows: list[dict], agent: Agent, source_root: Path) -> str:
    settings = {
        "questions": [(row["id"], row["question"]) for row in rows],
        "provider": agent.model.base_url,
        "model": agent.model.model,
        "corpus": agent.retriever.corpus.signature,
        "retrieval": agent.retriever.method,
        "rounds": agent.rounds,
        "max_calls": agent.max_calls,
        "skills": sorted(skill.name for skill in agent.skills.by_trigger.values()),
    }
    digest = sha256(json_text(settings).encode("utf-8"))
    for pattern in ("search_agent/*.py", "skills/*/SKILL.md"):
        for path in sorted(source_root.glob(pattern)):
            digest.update(path.read_bytes())
    return digest.hexdigest()


def run_batch(
    agent: Agent, source: Path, output: Path, workers: int, expected: int, source_root: Path
) -> dict:
    if not isinstance(agent.model, FlashClient):
        raise ValueError("Course batch generation requires the DeepSeek-V4-Flash API client.")
    rows = questions(source, expected)
    output.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(output) + ".lock", timeout=0):
        if output.exists():
            raise ValueError(f"Output already exists at {output}. Choose a new file or validate it.")
        checkpoint = output.parent / f".{output.name}.resume"
        checkpoint.mkdir(exist_ok=True)
        manifest = checkpoint / "run.jsonl"
        config = {"fingerprint": _fingerprint(rows, agent, source_root)}
        if manifest.exists() and read_jsonl(manifest) != [config]:
            raise ValueError("Existing checkpoint used different questions or settings. Choose a new output.")
        if not manifest.exists():
            atomic_jsonl(manifest, [config])
        records = {}
        todo = []
        for position, row in enumerate(rows):
            path = checkpoint / f"{position:04d}.jsonl"
            if path.exists():
                (record,) = read_jsonl(path)
                validate_record(record, row)
                records[position] = record
            else:
                todo.append((position, row, path))
        print(f"Resuming with {len(records)}/{len(rows)} complete records", flush=True)

        def predict(item: tuple[int, dict, Path]) -> tuple[int, dict]:
            position, row, path = item
            # Only the question text enters the agent. Validation answers stay outside it.
            result = agent.run(row["question"]).prediction(row["id"], row["question"])
            validate_record(result, row)
            atomic_jsonl(path, [result])
            return position, result

        if todo and not records:
            position, record = predict(todo.pop(0))
            records[position] = record
            print(f"Generated 1/{len(rows)}", flush=True)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for start in range(0, len(todo), workers):
                futures = [pool.submit(predict, item) for item in todo[start:start + workers]]
                failure = None
                for future in as_completed(futures):
                    try:
                        position, record = future.result()
                        records[position] = record
                        print(f"Generated {len(records)}/{len(rows)}", flush=True)
                    except (ModelError, OSError, ValueError) as error:
                        failure = error
                if failure:
                    raise ModelError(f"Batch paused after saving {len(records)} completed records. {failure}")
        atomic_jsonl(output, (records[i] for i in range(len(rows))))
        totals = validate_file(source, output, expected)
        for i in range(len(rows)):
            (checkpoint / f"{i:04d}.jsonl").unlink()
        manifest.unlink()
        checkpoint.rmdir()
        return totals
