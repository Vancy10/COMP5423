"""The agent's three callable tools and their argument validation."""

from .retrieval import Retriever


def _spec(name: str, description: str, fields: dict, required: list[str]) -> dict:
    return {"type": "function", "function": {
        "name": name, "description": description,
        "parameters": {
            "type": "object", "properties": fields, "required": required,
            "additionalProperties": False,
        },
    }}


TOOLS = [
    _spec(
        "search", "Retrieve ranked fixed-corpus documents with IDs, scores and relevant excerpts.",
        {"query": {"type": "string"}, "limit": {"type": "integer", "minimum": 1, "maximum": 6}},
        ["query"],
    ),
    _spec(
        "visit", "Read a longer passage in a surfaced document. Supply a clue or a character offset.",
        {"doc_id": {"type": "string"}, "query": {"type": "string"},
         "start": {"type": "integer", "minimum": 0}},
        ["doc_id"],
    ),
    _spec(
        "find", "Find a literal phrase in a surfaced document and return nearby text with offsets.",
        {"doc_id": {"type": "string"}, "phrase": {"type": "string"}},
        ["doc_id", "phrase"],
    ),
]


def _text(arguments: dict, field: str, maximum: int) -> str:
    value = arguments.get(field)
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"{field} must be a nonempty string of at most {maximum} characters.")
    return value.strip()


def invoke(retriever: Retriever, name: str, args: dict, known_docs: set[str]) -> dict:
    if name == "search":
        query = _text(args, "query", 800)
        limit = args.get("limit", 4)
        if type(limit) is not int or not 1 <= limit <= 6:
            raise ValueError("limit must be an integer from 1 to 6.")
        return retriever.search(query, limit)
    if name not in {"visit", "find"}:
        raise ValueError(f"Unknown tool: {name}")
    docid = _text(args, "doc_id", 100)
    if docid not in known_docs:
        raise ValueError("Search for the document before inspecting it.")
    if name == "find":
        return retriever.find(docid, _text(args, "phrase", 120))
    start = args.get("start")
    if start is not None and (type(start) is not int or start < 0):
        raise ValueError("start must be a nonnegative integer.")
    query = _text(args, "query", 420) if args.get("query") is not None else None
    return retriever.visit(docid, query, start)
