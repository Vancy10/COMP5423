"""Skill-augmented question answering over a fixed collection."""
