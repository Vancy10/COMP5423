"""An OpenAI-compatible client for the exact course backbone."""

from dataclasses import dataclass
import json
import os
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

OPENROUTER_URL = "https://openrouter.ai/api/v1"
OPENROUTER_MODEL = "deepseek/deepseek-v4-flash"


class ModelError(RuntimeError):
    pass


@dataclass(frozen=True)
class Completion:
    message: dict
    usage: dict
    model: str


class FlashClient:
    def __init__(self):
        self.base_url = os.environ.get("COMP5423_BASE_URL", OPENROUTER_URL).rstrip("/")
        parsed = urlsplit(self.base_url)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise ModelError("Set COMP5423_BASE_URL to the HTTPS base URL of the approved provider.")
        if parsed.query or parsed.fragment:
            raise ModelError("The API base URL cannot contain a query string or fragment.")
        self.openrouter = parsed.hostname == "openrouter.ai"
        self.model = os.environ.get("COMP5423_MODEL", OPENROUTER_MODEL if self.openrouter else "")
        self.key = os.environ.get("COMP5423_API_KEY") or (
            os.environ.get("OPENROUTER_API_KEY") if self.openrouter else None
        )
        if not self.model or not self.key:
            raise ModelError("Configure an API key and the provider's exact DeepSeek-V4-Flash model ID.")
        if self.openrouter and self.model != OPENROUTER_MODEL:
            raise ModelError(f"Select {OPENROUTER_MODEL} on OpenRouter for course runs.")
        if parsed.hostname == "api.deepseek.com":
            raise ModelError("DeepSeek's own flash aliases now serve V4.1. Configure an exact V4-Flash provider.")

    def complete(self, messages: list[dict], tools: list[dict], required: bool) -> Completion:
        body = {
            "model": self.model, "messages": messages, "temperature": 0.1, "max_tokens": 384,
        }
        if tools:
            body.update(tools=tools, tool_choice="required" if required else "auto")
        if self.openrouter:
            body["reasoning"] = {"enabled": False}
            body["provider"] = {"require_parameters": True}
        request = Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )
        request.add_unredirected_header("Authorization", f"Bearer {self.key}")
        result = self._request(request)
        try:
            message = result["choices"][0]["message"]
            usage = result["usage"]
            if type(usage["total_tokens"]) is not int or usage["total_tokens"] <= 0:
                raise ValueError("Missing token count")
            if not isinstance(message, dict):
                raise ValueError("Invalid assistant message")
        except (KeyError, TypeError, IndexError, ValueError) as error:
            raise ModelError("Provider response lacks a usable assistant message or token count.") from error
        if self.openrouter and result.get("model") not in {OPENROUTER_MODEL, OPENROUTER_MODEL + "-0423"}:
            raise ModelError("OpenRouter reported an unexpected backbone.")
        return Completion(message, usage, str(result.get("model") or self.model))

    @staticmethod
    def _request(request: Request) -> dict:
        for attempt in range(3):
            try:
                with urlopen(request, timeout=75) as reply:
                    return json.load(reply)
            except HTTPError as error:
                if error.code not in {429, 500, 502, 503, 504} or attempt == 2:
                    raise ModelError(f"Model API request failed (HTTP {error.code}).") from None
            except (URLError, TimeoutError, ConnectionError):
                if attempt == 2:
                    raise ModelError("Could not connect to the model API.") from None
            except (ValueError, TypeError) as error:
                raise ModelError("Model API response was not valid JSON.") from error
            time.sleep(2 ** (attempt + 1))
        raise AssertionError("API retry loop exhausted")
