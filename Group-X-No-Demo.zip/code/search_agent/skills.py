"""Discover skill metadata once and load the selected procedure on demand."""

from dataclasses import dataclass
from pathlib import Path
import re

import yaml

CLUE_MARKERS = re.compile(r"\b(?:that|which|whose|where|before|after|also|both|and)\b", re.I)


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    trigger: str
    path: Path

    def procedure(self) -> str:
        return self.path.read_text(encoding="utf-8").split("\n---\n", 1)[1].strip()


class Skills:
    def __init__(self, root: Path, enabled: bool = True):
        self.by_trigger: dict[str, Skill] = {}
        if enabled:
            for file in sorted(root.glob("*/SKILL.md")):
                with file.open(encoding="utf-8") as source:
                    if source.readline().strip() != "---":
                        raise ValueError(f"Missing frontmatter in {file}")
                    header = []
                    for line in source:
                        if line.strip() == "---":
                            break
                        header.append(line)
                    else:
                        raise ValueError(f"Unclosed YAML frontmatter in {file}")
                metadata = yaml.safe_load("".join(header))
                name = metadata["name"]
                description = metadata["description"]
                trigger = metadata["metadata"]["trigger"]
                if name != file.parent.name or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name):
                    raise ValueError(f"Invalid skill name in {file}")
                if not isinstance(description, str) or not description or trigger in self.by_trigger:
                    raise ValueError(f"Invalid description or duplicate trigger in {file}")
                self.by_trigger[trigger] = Skill(name, description, trigger, file)

    def select(self, question: str, stalled: bool) -> tuple[Skill | None, str]:
        if stalled and "stalled-search" in self.by_trigger:
            return self.by_trigger["stalled-search"], "The latest search added no document IDs."
        clues = len(CLUE_MARKERS.findall(question))
        if (clues >= 2 or (clues == 1 and len(question.split()) >= 32)) and "multiple-clues" in self.by_trigger:
            return self.by_trigger["multiple-clues"], "The question contains multiple linked clues."
        return None, "No skill trigger matched."
