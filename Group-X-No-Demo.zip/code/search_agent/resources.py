"""Download the course splits and pinned, public corpus and retriever assets."""

from concurrent.futures import ThreadPoolExecutor
from hashlib import file_digest
from pathlib import Path
import shutil
import tempfile
import time
from urllib.request import Request, urlopen

from .corpus import CORPUS_REVISION

HF = "https://huggingface.co"
VAL = "HongruCai/COMP5423-BrowseComp-Plus-Val"
TEST = "HongruCai/COMP5423-BrowseComp-Plus-Test"
CORPUS = "Tevatron/browsecomp-plus-corpus"
QWEN_INDEX = "Tevatron/browsecomp-plus-indexes"
QWEN_INDEX_REVISION = "b3f37f70c33829eb09d04784a54277a31871fd63"
E5_FOLDER = "e5-small-v2"
QWEN_FOLDER = "qwen3-embedding-0.6b"

CORPUS_HASHES = (
    "7c07f9e23b1ca548110fd831714cadc67d44db5223bace6e45fcaa795d3153d0",
    "e92d8202e0f656a85b262153dbcd22ecf80ea2d0c96d9884f9c8e25480b869ab",
    "0e4113a4503342527258d8f2c49877747435f3e65bfe1f7306b4f488c8d225fe",
    "0ceea5e703332a2e3ce700f641273400d84583fad84b659d3248ed06d3a9fef3",
    "15b62914ddc3de6946893c770f07d5d84d29646e833ca1447955668f2b57940c",
    "a9a75708ad37c522e93a774e5a968a3129e12b0559971c8f950a5628e0201df0",
    "290062b60c1a6ebba7d5469a37a431f0a2596e68788295284b1b2d35db07b62c",
)
QWEN_HASHES = (
    "dcbe89464488f5dd03c70be5d580c3359a5a71795bf1011cdfe8dfe8567d572c",
    "8ee02040dd54deee6d3280c66dcd14429ec21833cc51196fe1d2f67dfdc4a4df",
    "bc89d5d90e8bdf127a194db6e1a352e26ca9c7a882d1da8feebbe19271c9c796",
    "6638bed8f88f4d8286af05d3c4bb232c83c2e869d1908bd400047889fe9b34bf",
)

MODEL_FILES = {
    E5_FOLDER: (
        "intfloat/e5-small-v2",
        "ffb93f3bd4047442299a41ebb6fa998a38507c52",
        ("config.json", "model.safetensors", "tokenizer.json", "tokenizer_config.json",
         "special_tokens_map.json", "vocab.txt"),
    ),
    QWEN_FOLDER: (
        "Qwen/Qwen3-Embedding-0.6B",
        "97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3",
        ("config.json", "model.safetensors", "tokenizer.json", "tokenizer_config.json",
         "merges.txt", "vocab.json"),
    ),
}


def qwen_shards(root: Path):
    for i, checksum in enumerate(QWEN_HASHES, 1):
        filename = f"corpus.shard{i}_of_4.pkl"
        yield root / "qwen-prebuilt" / filename, checksum


def checksum_matches(path: Path, sha: str) -> bool:
    with path.open("rb") as handle:
        return file_digest(handle, "sha256").hexdigest() == sha


def _download(url: str, path: Path, checksum: str | None) -> str:
    if path.is_file() and path.stat().st_size and (not checksum or checksum_matches(path, checksum)):
        return f"Ready: {path.name}"
    path.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(3):
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as output:
            temporary = Path(output.name)
        try:
            request = Request(url, headers={"User-Agent": "COMP5423-search-agent/1.0"})
            with urlopen(request, timeout=120) as reply, temporary.open("wb") as output:
                shutil.copyfileobj(reply, output, length=1024 * 1024)
            if not temporary.stat().st_size or (checksum and not checksum_matches(temporary, checksum)):
                raise ValueError(f"Invalid download: {path.name}")
            temporary.replace(path)
            return f"Downloaded: {path.name}"
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(attempt + 1)
        finally:
            temporary.unlink(missing_ok=True)
    raise AssertionError("Download retry loop exhausted")


def fetch(root: Path, group: str) -> None:
    assets = []
    if group in {"splits", "all"}:
        for repo, revision, filename in (
            (VAL, "4600dbab149ad6575e109867f5b7685712cd70a7", "validation.jsonl"),
            (TEST, "9cb2f4b9758f97c8bb4275c6d81f8d134bb3eadb", "test.jsonl"),
        ):
            assets.append((f"{HF}/datasets/{repo}/resolve/{revision}/{filename}", root / filename, None))
    if group in {"corpus", "all"}:
        for i, checksum in enumerate(CORPUS_HASHES):
            filename = f"train-{i:05d}-of-00007.parquet"
            assets.append((f"{HF}/datasets/{CORPUS}/resolve/{CORPUS_REVISION}/data/{filename}",
                           root / "corpus" / filename, checksum))
    if group in {"dense", "instruct", "all"}:
        folders = {
            "dense": (E5_FOLDER,), "instruct": (QWEN_FOLDER,), "all": (E5_FOLDER, QWEN_FOLDER)
        }[group]
        for folder in folders:
            repo, revision, names = MODEL_FILES[folder]
            for name in names:
                assets.append((f"{HF}/{repo}/resolve/{revision}/{name}",
                               root / "models" / folder / name, None))
    if group in {"instruct", "all"}:
        for path, checksum in qwen_shards(root):
            assets.append((f"{HF}/datasets/{QWEN_INDEX}/resolve/{QWEN_INDEX_REVISION}/"
                           f"{QWEN_FOLDER}/{path.name}", path, checksum))
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = pool.map(lambda asset: _download(*asset), assets)
        for result in results:
            print(result, flush=True)
