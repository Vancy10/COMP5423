"""Validation metrics for retrieval configurations and completed agent runs."""

from collections import defaultdict
from pathlib import Path
from statistics import median
from time import perf_counter

from .dataset import normalize, questions, read_jsonl
from .retrieval import RRF_DEPTH, Retriever, reciprocal_rank_fusion


def retrieval_metrics(retriever: Retriever, validation: Path) -> dict:
    rows = questions(validation, labeled=True)
    profiles = list(retriever.channels)
    if len(profiles) > 1:
        profiles.append("hybrid")
    totals = {name: defaultdict(int) for name in profiles}
    timings = {name: [] for name in profiles}
    for i, row in enumerate(rows, start=1):
        query = row["question"]
        label = normalize(row["answer"])
        ranked = {}
        elapsed = {}
        for channel in retriever.channels:
            start = perf_counter()
            ranked[channel] = retriever.rank_channel(channel, query, RRF_DEPTH)
            elapsed[channel] = perf_counter() - start
        if "hybrid" in totals:
            start = perf_counter()
            ranked["hybrid"] = reciprocal_rank_fusion(list(ranked.values()), 10)
            elapsed["hybrid"] = sum(elapsed.values()) + (perf_counter() - start)
        documents = {}
        for profile in profiles:
            selected = ranked[profile][:10]
            for docid, _ in selected:
                if docid not in documents:
                    documents[docid] = f" {normalize(retriever.corpus.get(docid).text)} "
            hits = [bool(label) and f" {label} " in documents[docid] for docid, _ in selected]
            snippets = retriever.snippets(query, selected[:5])
            for k in (1, 5, 10):
                totals[profile][f"document_hit_at_{k}"] += any(hits[:k])
            totals[profile]["snippet_hit_at_5"] += bool(label) and any(
                f" {label} " in f" {normalize(item['snippet'])} " for item in snippets
            )
            timings[profile].append(elapsed[profile] * 1000)
        if i % 20 == 0:
            print(f"Evaluated {i}/{len(rows)} validation questions", flush=True)
    return {
        "questions": len(rows), "documents": retriever.corpus.count,
        "metric": "normalized answer-string containment (counts; no answer generation)",
        "profiles": {
            name: {**totals[name], "median_rank_ms": round(median(timings[name]), 1)}
            for name in profiles
        },
    }


def prediction_metrics(validation: Path, output: Path) -> dict:
    from .batch import validate_record

    refs = {row["id"]: row for row in questions(validation, labeled=True)}
    predictions = read_jsonl(output)
    hits = calls = tokens = 0
    seen = set()
    for prediction in predictions:
        key = prediction.get("id")
        if key not in refs or key in seen:
            raise ValueError(f"Unexpected or duplicate prediction ID: {key}")
        seen.add(key)
        row = refs[key]
        validate_record(prediction, row)
        hits += normalize(prediction["answer"]) == normalize(row["answer"])
        calls += prediction["tool_calls"]
        tokens += prediction["total_tokens"]
    if set(refs) != seen:
        raise ValueError(f"Missing {len(refs) - len(seen)} validation predictions")
    return {
        "questions": len(refs), "exact_matches": hits, "normalized_em_percent": 100 * hits / len(refs),
        "total_tool_calls": calls, "total_api_tokens": tokens,
    }
