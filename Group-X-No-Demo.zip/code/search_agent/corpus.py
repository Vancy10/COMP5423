"""Fixed corpus storage and a full-text BM25 index."""

from collections.abc import Iterable, Iterator
from contextlib import closing
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3
import tempfile
from urllib.parse import urlsplit
import zlib

CORPUS_SIZE = 100_195
CORPUS_REVISION = "b27b02bc3e45511b8b82a13e6f90ce761df726f6"
SCHEMA_VERSION = 2
FRONTMATTER_TITLE = re.compile(r"^title:[ \t]*(\S[^\r\n]*)", re.I | re.M)


@dataclass(frozen=True)
class Document:
    docid: str
    url: str
    text: str

    @property
    def heading(self) -> str:
        first, _, rest = self.text.lstrip().partition("\n")
        if first.strip() == "---":
            header = rest[:3000].partition("\n---")[0]
            matched = FRONTMATTER_TITLE.search(header)
            if matched:
                return matched[1].strip().strip("\"'")[:160]
            try:
                return urlsplit(self.url).hostname or self.docid
            except ValueError:
                return self.docid
        return first.strip()[:160] or self.docid


def documents_from_parquet(directory: Path) -> Iterator[Document]:
    import pyarrow.parquet as pq

    shards = [directory / f"train-{i:05d}-of-00007.parquet" for i in range(7)]
    missing = [path.name for path in shards if not path.is_file()]
    if missing:
        raise ValueError(f"Run fetch corpus first. Missing {', '.join(missing)}")
    for path in shards:
        for batch in pq.ParquetFile(path).iter_batches(
            batch_size=128, columns=["docid", "url", "text"]
        ):
            for row in batch.to_pylist():
                yield Document(str(row["docid"]), row["url"], row["text"])


def build_index(
    destination: Path, documents: Iterable[Document], expected_count: int | None = None
) -> tuple[int, str]:
    """Publish the database only after every document was indexed."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destination.parent, prefix=".index-") as scratch:
        database = Path(scratch) / "corpus.sqlite"
        digest = sha256()
        insert_rows = []
        with closing(sqlite3.connect(database)) as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=OFF;
                PRAGMA synchronous=OFF;
                PRAGMA cache_size=-196608;
                CREATE TABLE documents (
                    rowid INTEGER PRIMARY KEY, docid TEXT NOT NULL UNIQUE,
                    url TEXT NOT NULL, body BLOB NOT NULL
                );
                CREATE VIRTUAL TABLE lexical USING fts5(
                    heading, body, content='', tokenize='porter unicode61 remove_diacritics 2'
                );
                CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                """
            )
            count = 0
            for count, doc in enumerate(documents, start=1):
                fingerprint = json.dumps([doc.docid, doc.url, doc.text], ensure_ascii=False)
                digest.update(fingerprint.encode("utf-8"))
                digest.update(b"\n")
                insert_rows.append((count, doc))
                if len(insert_rows) == 128:
                    _insert_documents(connection, insert_rows)
                    insert_rows.clear()
                if count % 10_000 == 0:
                    print(f"Indexed {count:,} documents", flush=True)
            _insert_documents(connection, insert_rows)
            if not count or (expected_count is not None and count != expected_count):
                raise ValueError(f"Expected {expected_count} documents, found {count}")
            signature = digest.hexdigest()
            connection.executemany(
                "INSERT INTO metadata VALUES (?, ?)",
                [
                    ("schema", str(SCHEMA_VERSION)), ("count", str(count)),
                    ("signature", signature),
                ],
            )
            connection.execute("INSERT INTO lexical(lexical, rank) VALUES ('automerge', 4)")
            connection.execute("INSERT INTO lexical(lexical) VALUES ('optimize')")
            connection.commit()
        database.replace(destination)
    return count, signature


def _insert_documents(connection: sqlite3.Connection, rows: list[tuple[int, Document]]) -> None:
    connection.executemany(
        "INSERT INTO documents VALUES (?, ?, ?, ?)",
        ((i, doc.docid, doc.url, zlib.compress(doc.text.encode("utf-8"), 1)) for i, doc in rows),
    )
    connection.executemany(
        "INSERT INTO lexical(rowid, heading, body) VALUES (?, ?, ?)",
        ((i, doc.heading, doc.text) for i, doc in rows),
    )
    connection.commit()


class Corpus:
    def __init__(self, path: Path):
        path = path.resolve()
        if not path.is_file():
            raise ValueError(f"Corpus index missing at {path}. Run index first.")
        self.uri = path.as_uri() + "?mode=ro"
        with closing(self.connect()) as db:
            metadata = dict(db.execute("SELECT key, value FROM metadata"))
        if metadata.get("schema") != str(SCHEMA_VERSION):
            raise ValueError("Corpus schema changed. Rebuild the index.")
        self.count = int(metadata["count"])
        self.signature = metadata["signature"]

    def connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.uri, uri=True)

    def get(self, docid: str) -> Document:
        with closing(self.connect()) as db:
            row = db.execute(
                "SELECT url, body FROM documents WHERE docid=?", (docid,)
            ).fetchone()
        if row is None:
            raise ValueError(f"Unknown document ID: {docid}")
        url, body = row
        return Document(docid, url, zlib.decompress(body).decode("utf-8"))

    def ids(self) -> list[str]:
        with closing(self.connect()) as db:
            return [row[0] for row in db.execute("SELECT docid FROM documents ORDER BY rowid")]

    def iter_documents(self) -> Iterator[Document]:
        with closing(self.connect()) as db:
            for docid, url, body in db.execute(
                "SELECT docid, url, body FROM documents ORDER BY rowid"
            ):
                yield Document(docid, url, zlib.decompress(body).decode("utf-8"))

    def bm25(self, match: str, limit: int) -> list[tuple[str, float]]:
        with closing(self.connect()) as db:
            return db.execute(
                """
                SELECT d.docid, -lexical.rank
                FROM lexical JOIN documents AS d ON d.rowid=lexical.rowid
                WHERE lexical MATCH ? AND lexical.rank MATCH 'bm25(3.0,1.0)'
                ORDER BY lexical.rank, lexical.rowid LIMIT ?
                """,
                (match, limit),
            ).fetchall()
