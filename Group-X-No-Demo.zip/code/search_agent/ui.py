"""Interactive terminal views of the actual agent and tool output."""

import json
import re
from textwrap import fill

from .agent import Agent, Answer
from .llm import ModelError

TERMINAL_WIDTH = 96
CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")


def clean(value: str) -> str:
    return " ".join(CONTROL.sub("", value).split())


def wrapped(value: str, prefix: str = "", continuation: str | None = None) -> str:
    return fill(clean(value), width=TERMINAL_WIDTH, initial_indent=prefix,
                subsequent_indent=prefix if continuation is None else continuation)


def show_events(step: dict) -> None:
    if step.get("event") == "skill_selection":
        print(f"  Skill  {step['skill'] or 'none'} | {step['content']}", flush=True)
    if step["role"] != "tool":
        return
    result = json.loads(step["content"])
    name = step["name"]
    if "error" in result:
        text = f"{name} | {result['error']}"
    elif name == "search":
        ids = " ".join(item["doc_id"] for item in result["results"])
        text = f"search | {result['query']} -> {ids or 'no matches'}"
    elif name == "visit":
        text = f"visit | {result['doc_id']} [{result['start']}:{result['end']}]"
    else:
        text = f"find | {result['doc_id']} / {result['phrase']} -> {len(result['matches'])} match(es)"
    print(wrapped(text, "  "), flush=True)


def show_answer(result: Answer) -> None:
    print(f"\nAnswer  {clean(result.answer) or '(no supported answer)'}")
    if result.evidence:
        print("Supporting passages")
    for item in result.evidence:
        print(wrapped(f"[{item['doc_id']}] {item['heading']}", "  "))
        excerpt = clean(item["text"])
        print(wrapped(excerpt if len(excerpt) <= 250 else excerpt[:247] + "...", "    "))
        print(wrapped(item["url"], "    "))
    print(f"\nUsage   {result.tool_calls} tool calls | {result.total_tokens:,} API tokens")


def ask(agent: Agent, question: str) -> Answer:
    print(wrapped(question, "Question  ", "          "))
    print("\nSearch progress")
    result = agent.run(question, on_event=show_events)
    show_answer(result)
    return result


def shell(agent: Agent) -> None:
    print(f"COMP5423 Search Agent | {agent.retriever.method} | {agent.retriever.corpus.count:,} documents")
    print("Enter a question, or type :quit to exit.")
    while True:
        try:
            question = input("\n> ").strip()
            if question == ":quit":
                return
            if question:
                ask(agent, question)
        except (EOFError, KeyboardInterrupt):
            return
        except (ModelError, ValueError) as error:
            print(f"Request failed: {error}")


def show_retrieval(result: dict) -> None:
    print(wrapped(result["query"], "Query  ", "       "))
    print(f"\nRanked results  [{result['method']}]")
    for i, item in enumerate(result["results"], 1):
        print(wrapped(f"{i}. [{item['doc_id']}] {item['heading']}  |  {item['score']:.5f}", "  "))
        excerpt = clean(item["snippet"])
        print(wrapped(excerpt if len(excerpt) <= 270 else excerpt[:267] + "...", "     "))
        print(wrapped(item["url"], "     "))
