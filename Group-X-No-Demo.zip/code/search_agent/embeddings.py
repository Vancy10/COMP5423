"""Corpus-wide vector search using E5 and instruction-conditioned Qwen3."""

from pathlib import Path
import pickle
from threading import Lock
import tempfile

import numpy as np

from .corpus import Corpus
from .resources import E5_FOLDER, QWEN_FOLDER, checksum_matches, qwen_shards

E5_LENGTH = 192
QUERY_LENGTH = 384
QWEN_TASK = "Given a web search query, retrieve relevant passages that answer the query"
DIMENSION = {"dense": 384, "instruct": 1024}
FOLDER = {"dense": E5_FOLDER, "instruct": QWEN_FOLDER}


class Encoder:
    def __init__(self, root: Path, method: str, device: str):
        import torch
        from transformers import AutoModel, AutoTokenizer

        path = root / "models" / FOLDER[method]
        if not (path / "model.safetensors").is_file():
            raise ValueError(f"Embedding model missing at {path}. Run fetch {method} first.")
        self.torch = torch
        self.method = method
        self.device = torch.device(
            ("cuda" if torch.cuda.is_available() else "cpu") if device == "auto" else device
        )
        if self.device.type == "cuda" and not torch.cuda.is_available():
            raise ValueError("CUDA is unavailable. Install a CUDA PyTorch wheel or use --device cpu.")
        if self.device.type == "cpu":
            torch.set_num_threads(min(6, torch.get_num_threads()))
        dtype = torch.float16 if self.device.type == "cuda" else torch.float32
        self.tokenizer = AutoTokenizer.from_pretrained(path, local_files_only=True)
        self.model = AutoModel.from_pretrained(
            path, local_files_only=True, use_safetensors=True, torch_dtype=dtype
        ).to(self.device).eval()
        self.lock = Lock()

    def encode(self, texts: list[str], *, query: bool) -> np.ndarray:
        if self.method == "dense":
            prefix = "query: " if query else "passage: "
        else:
            prefix = f"Instruct: {QWEN_TASK}\nQuery: " if query else ""
        torch = self.torch
        with self.lock, torch.inference_mode():
            tokens = self.tokenizer(
                [prefix + text for text in texts],
                padding=True, truncation=True, max_length=QUERY_LENGTH if query else E5_LENGTH,
                return_tensors="pt",
            ).to(self.device)
            hidden = self.model(**tokens).last_hidden_state.float()
            mask = tokens["attention_mask"]
            if self.method == "dense":
                pooled = (hidden * mask.unsqueeze(-1)).sum(1) / mask.sum(1, keepdim=True)
            else:
                positions = torch.arange(mask.shape[1], device=self.device) * mask
                pooled = hidden[torch.arange(len(texts), device=self.device), positions.max(1).values]
            return torch.nn.functional.normalize(pooled, dim=1).cpu().numpy()


class ArrayUnpickler(pickle.Unpickler):
    """Decode the hash-pinned Tevatron shards with an allowlist of NumPy globals."""

    def find_class(self, module: str, name: str):
        if module == "numpy" and name in {"ndarray", "dtype"}:
            return getattr(np, name)
        if module in {"numpy.core.multiarray", "numpy._core.multiarray"} and name == "_reconstruct":
            return np._core.multiarray._reconstruct
        raise pickle.UnpicklingError(f"Unexpected global in upstream vector file: {module}.{name}")


def build_vectors(root: Path, corpus: Corpus, method: str, device: str, batch_size: int) -> Path:
    vectors = np.empty((corpus.count, DIMENSION[method]), dtype=np.float32)
    if method == "dense":
        _encode_corpus(root, corpus, vectors, device, batch_size)
    else:
        _import_qwen(root, corpus, vectors)
    target = root / f"{method}.npz"
    with tempfile.NamedTemporaryFile(dir=root, delete=False) as output:
        temporary = Path(output.name)
    try:
        with temporary.open("wb") as output:
            np.savez(output, vectors=vectors, signature=np.array(corpus.signature))
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    return target


def _encode_corpus(root: Path, corpus: Corpus, vectors: np.ndarray, device: str, batch: int) -> None:
    encoder = Encoder(root, "dense", device)
    texts: list[str] = []
    offset = 0
    for doc in corpus.iter_documents():
        texts.append(doc.text[:2800])
        if len(texts) == batch:
            vectors[offset:offset + batch] = encoder.encode(texts, query=False)
            offset += batch
            if offset % (batch * 40) == 0:
                print(f"E5 on {encoder.device}: {offset:,}/{corpus.count:,}", flush=True)
            texts.clear()
    if texts:
        vectors[offset:] = encoder.encode(texts, query=False)


def _import_qwen(root: Path, corpus: Corpus, vectors: np.ndarray) -> None:
    positions = {docid: i for i, docid in enumerate(corpus.ids())}
    for path, digest in qwen_shards(root):
        if not path.is_file() or not checksum_matches(path, digest):
            raise ValueError(f"Missing or invalid shard {path.name}. Run fetch instruct first.")
        with path.open("rb") as handle:
            embeddings, ids = ArrayUnpickler(handle).load()
        if embeddings.shape != (len(ids), DIMENSION["instruct"]):
            raise ValueError(f"Unexpected vector dimensions in {path.name}")
        norm = np.linalg.norm(embeddings, axis=1, keepdims=True)
        if not np.all(np.isfinite(norm) & (norm > 0)):
            raise ValueError(f"Invalid vectors in {path.name}")
        try:
            rows = [positions.pop(str(docid)) for docid in ids]
        except KeyError as error:
            raise ValueError("Qwen shard contains an unknown or duplicate document ID") from error
        vectors[rows] = embeddings / norm
        print(f"Aligned {len(ids):,} Qwen vectors from {path.name}", flush=True)
    if positions:
        raise ValueError(f"Qwen shards are missing {len(positions)} indexed documents")


class VectorRanker:
    def __init__(self, root: Path, corpus: Corpus, method: str, device: str):
        path = root / f"{method}.npz"
        if not path.is_file():
            raise ValueError(f"Missing {path.name}. Run index --method {method} first.")
        with np.load(path, allow_pickle=False) as index:
            self.vectors = index["vectors"]
            if index["signature"].item() != corpus.signature:
                raise ValueError(f"{method} vectors are out of sync with the document database")
        if self.vectors.shape != (corpus.count, DIMENSION[method]):
            raise ValueError(f"{method} vector index has unexpected dimensions")
        self.ids = corpus.ids()
        self.encoder = Encoder(root, method, device)

    def rank(self, query: str, limit: int) -> list[tuple[str, float]]:
        query_vector = self.encoder.encode([query], query=True)[0]
        scores = self.vectors @ query_vector
        order = np.argsort(-scores, kind="stable")[:limit]
        return [(self.ids[i], float(scores[i])) for i in order]
