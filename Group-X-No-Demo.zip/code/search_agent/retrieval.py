"""Rank fixed documents and extract source passages with character offsets."""

from collections import Counter, defaultdict
from pathlib import Path
import re

from .corpus import Corpus, Document

PROFILES = {
    "sparse": ("sparse",),
    "dense": ("dense",),
    "instruct": ("instruct",),
    "hybrid": ("sparse", "dense", "instruct"),
}
WORD = re.compile(r"[^\W_]+")
STOPWORDS = set(
    """a an and are as at be been being but by can could did do does for from had has have
    he her hers him his how i if in is it its may me might my no of on or our out she so some
    than that the their them these they this those to up very was we were what when where
    which who whom whose will with would you your please give tell based according also
    identify find name called know something someone during become became while before
    after about into any between each other over once only first last many most""".split()
)
RRF_DEPTH = 40
RRF_CONSTANT = 30
SNIPPET_CHARS = 650
PASSAGE_CHARS = 1_400


def terms(query: str) -> list[str]:
    words = [word.lower() for word in WORD.findall(query)]
    content = [word for word in words if word not in STOPWORDS and (len(word) > 1 or word.isnumeric())]
    return list(dict.fromkeys(content or words))[:24]


def best_offset(text: str, query: str, width: int) -> int:
    wanted = set(terms(query))
    if len(text) <= width or not wanted:
        return 0
    hits = [(word.start(), word[0].lower()) for word in WORD.finditer(text) if word[0].lower() in wanted]
    counts: Counter[str] = Counter()
    best = (0, 0)
    start = upper = 0
    for lower, (left, _) in enumerate(hits):
        while upper < len(hits) and hits[upper][0] < left + width - 42:
            counts[hits[upper][1]] += 1
            upper += 1
        score = (len(counts), min(upper - lower, 2 * len(counts)))
        if score > best:
            best = score
            start = max(0, left - 42)
        word = hits[lower][1]
        counts[word] -= 1
        if not counts[word]:
            del counts[word]
    start = min(start, len(text) - width)
    if start > 0 and text[start - 1].isalnum() and text[start].isalnum():
        boundary = re.search(r"\s", text[start:start + 24])
        if boundary:
            start += boundary.end()
    return start


def passage(doc: Document, start: int, width: int) -> dict:
    start = min(start, len(doc.text))
    end = min(len(doc.text), start + width)
    return {
        "doc_id": doc.docid, "url": doc.url, "heading": doc.heading,
        "start": start, "end": end, "text": doc.text[start:end],
    }


def reciprocal_rank_fusion(rankings: list[list[tuple[str, float]]], limit: int):
    votes: dict[str, float] = defaultdict(float)
    for ranking in rankings:
        for rank, (docid, _) in enumerate(ranking, 1):
            votes[docid] += 1.0 / (RRF_CONSTANT + rank)
    return sorted(votes.items(), key=lambda row: (-row[1], row[0]))[:limit]


class Retriever:
    def __init__(self, corpus: Corpus, root: Path, method: str, device: str = "auto"):
        self.corpus = corpus
        self.method = method
        self.channels = PROFILES[method]
        self.vector_rankers = {}
        if self.channels != ("sparse",):
            from .embeddings import VectorRanker

            self.vector_rankers = {
                channel: VectorRanker(root, corpus, channel, device)
                for channel in self.channels if channel != "sparse"
            }

    def rank_channel(self, channel: str, query: str, limit: int):
        if channel != "sparse":
            return self.vector_rankers[channel].rank(query, limit)
        query_terms = terms(query)
        if not query_terms:
            return []
        # Quoting individual lexical terms prevents user or model text becoming FTS syntax.
        match = " OR ".join(f'"{word}"' for word in query_terms)
        return self.corpus.bm25(match, limit)

    def rank(self, query: str, limit: int):
        if len(self.channels) == 1:
            return self.rank_channel(self.channels[0], query, limit)
        rankings = [self.rank_channel(channel, query, RRF_DEPTH) for channel in self.channels]
        return reciprocal_rank_fusion(rankings, limit)

    def snippets(self, query: str, ranked: list[tuple[str, float]]) -> list[dict]:
        results = []
        for docid, score in ranked:
            doc = self.corpus.get(docid)
            item = passage(doc, best_offset(doc.text, query, SNIPPET_CHARS), SNIPPET_CHARS)
            item["snippet"] = item.pop("text")
            item["score"] = round(score, 8)
            results.append(item)
        return results

    def search(self, query: str, limit: int) -> dict:
        return {"query": query, "method": self.method, "results": self.snippets(query, self.rank(query, limit))}

    def visit(self, docid: str, query: str | None, start: int | None) -> dict:
        doc = self.corpus.get(docid)
        if start is None:
            start = best_offset(doc.text, query or "", PASSAGE_CHARS)
        return {**passage(doc, start, PASSAGE_CHARS), "length": len(doc.text)}

    def find(self, docid: str, phrase: str) -> dict:
        doc = self.corpus.get(docid)
        matches = []
        for match in re.finditer(re.escape(phrase), doc.text, re.IGNORECASE):
            context = passage(doc, max(0, match.start() - 95), len(phrase) + 190)
            matches.append({**context, "match_start": match.start(), "match_end": match.end()})
            if len(matches) == 4:
                break
        return {"doc_id": docid, "phrase": phrase, "matches": matches}
